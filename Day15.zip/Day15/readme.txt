# Day 15 – Networking Basics

## 🔹 What is Networking?
- **Simple:** Networking means connecting **computers, servers, and devices** so they can **talk to each other** and **share data**.  
- Example: When you open **netflix.com**, your laptop connects to Netflix’s servers over the internet.  

**Why it matters in Cloud/DevOps:**  
- All cloud services (AWS, GCP, Azure) rely on networking: VPCs, subnets, load balancers, firewalls, etc.  
- DevOps engineers must know how apps communicate securely and efficiently.

---

## 🔹 OSI Model (7 Layers)
Think of it like a **postal system** (step-by-step delivery).  

1. **Physical** – cables, WiFi, signals.  
   *Wires carrying bits (0s and 1s).*  
2. **Data Link** – switches, MAC addresses.  
   *Post office worker sorting letters.*  
3. **Network** – IP addresses, routers.  
   *The GPS deciding the delivery route.*  
4. **Transport** – TCP/UDP.  
   *Ensures delivery is complete (TCP) or fast (UDP).*  
5. **Session** – session management.  
   *Opening/closing a phone call.*  
6. **Presentation** – data format, encryption.  
   *Translating languages or encoding/decoding.*  
7. **Application** – HTTP, DNS, FTP, SSH.  
   *The app you see: Netflix, Gmail, browser.*  

👉 In practice, Cloud/DevOps focuses most on **Layers 3–7**.

---

## 🔹 TCP (Transmission Control Protocol)
- Ensures data is **reliable, ordered, and complete**.  
- Uses **3-way handshake** before communication.  
- Used for: websites (HTTP/HTTPS), emails (SMTP), file transfers (FTP).  

👉 Like sending a package **with tracking**.

---

## 🔹 IP (Internet Protocol)
- Assigns **addresses** to devices (IPv4/IPv6).  
- Responsible for **routing** data across networks.  
- Example: `192.168.1.5` (private), `142.250.185.46` (Google server).  

👉 Like the **house address** on your parcel.

---

## 🔹 Subnet
- Subnet = **smaller network inside a bigger network**.  
- Helps **organize** and **secure** traffic.  
- Example:  
  - Office LAN: `192.168.1.0/24`  
  - Servers subnet: `192.168.1.0 – 192.168.1.127`  
  - Users subnet: `192.168.1.128 – 192.168.1.255`  

👉 In Cloud (AWS/GCP): You create **VPCs** and divide them into **subnets** (public for web servers, private for databases).

---

## 🔹 Putting It All Together
When you visit **netflix.com**:
1. **IP** finds Netflix’s server address.  
2. **TCP** ensures all video packets arrive correctly.  
3. **Subnet** decides if your request comes from home WiFi or office network.  
4. **OSI model** layers process your request step by step until the video plays.  

---

✅ **Summary for Day 15**
- **Networking:** Devices connecting + sharing data.  
- **OSI Model:** 7 layers → Physical to Application.  
- **TCP:** Reliable communication.  
- **IP:** Addressing + routing.  
- **Subnet:** Smaller networks for organization/security.  
